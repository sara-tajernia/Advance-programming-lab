import java.util.Scanner;

/**
 *  othello game
 *  we use this class to test all the classes that we made
 *  and give input by scanning and test all the possibilities
 *  that can happen like chose the wrong place
 *  <h2>Library  simulation  class</h2>
 *  @author Sara Tajernia
 *  @version 1.00
 *  @since 1399-1-17
 */

public class Main {

    public static void main(String[] args) {

        int map[][] = new int [10][10];

        for (int counter1=0; counter1<10; counter1++){
            for (int counter2=0; counter2<10; counter2++){
                map[counter1][counter2] = 0;
            }
        }
        map[4][4] = 2;
        map[5][4] = 1;
        map[4][5] = 1;
        map[5][5] = 2;

        Scanner scan = new Scanner(System.in);

        System.out.println("1) single player");                           //menu
        System.out.println("2) multiplayer");

        int menu= scan.nextInt();


        Board board = new Board(map);
        board.print();                                                     //print for start a game

        if(menu == 1) {                                                     //single player
            int x, y;
            System.out.println("You are \u26AA!");
            while (!board.checkOver()) {                                    //check the game is not over
                while (true) {                                              //while chose the right place if it exist
                    System.out.println("Your turn: ");
                    boolean chechPass1 = false;
                    for (int counter1 = 1; counter1 <= 8; counter1++) {
                        for (int counter2 = 1; counter2 <= 8; counter2++) {
                            Rule play = new Rule(map, counter2, counter1, 1);
                            if (play.checkMove()) {
                                chechPass1 = true;                          //check if at least one place exist for nut
                            }
                        }
                    }
                    if (chechPass1) {
                        y = scan.nextInt();
                        x = scan.next().charAt(0) - 64;

                        Rule play1 = new Rule(map, x, y, 1);
                        if (play1.checkMove()) {
                            map[x][y] = 1;                                  //put the nut
                            map = play1.Move();                             //move the other nuts
                            board.print();
                            break;
                        }
                        else
                            System.out.println("You cant choose this place");
                    }
                    else {
                        System.out.println("PASS");
                        break;
                    }
                }
                if(!board.checkOver()){                                     //computers turn
                    int maxX=0, maxY=0, maxPoint=0;
                    while (true){
                        boolean chechPass2 = false;
                        for (int counter1=1; counter1<=8; counter1++) {
                            for (int counter2 = 1; counter2 <= 8; counter2++) {
                                Rule play = new Rule(map, counter2, counter1, 2);;
                                if(play.checkMove()) {
                                    chechPass2 = true;                        //check if eny place exist
                                    if(play.getMaxPoint()> maxPoint){
                                        maxPoint=play.getMaxPoint();           //save the place that has the max point to choose that
                                        maxX=play.getX();
                                        maxY=play.getY();
                                    }

                                }
                            }
                        }
                        if(chechPass2){
                            y = maxY;                                       //put the best place for nut
                            x = maxX;

                            Rule play1 = new Rule(map, x, y, 2);
                            if(play1.checkMove()){
                                map[x][y]=2;
                                map= play1.Move();
                                board.print();
                                break;
                            }
                            else
                                System.out.println("You cant choose this place");
                        }
                        else {
                            System.out.println("PASS");
                            break;
                        }
                    }

                }
            }
        }


        if(menu == 2){                                                  //multiplayer
            int x,y;
            while (!board.checkOver()){                                 //do the same as single player 1
                while (true){
                    System.out.println("White: ");
                    boolean chechPass1 = false;
                    for (int counter1=1; counter1<=8; counter1++) {
                        for (int counter2 = 1; counter2 <= 8; counter2++) {
                            Rule play = new Rule(map, counter2, counter1, 1);
                            if(play.checkMove()) {
                                chechPass1 = true;
                            }
                        }
                    }
                    if(chechPass1){
                        y = scan.nextInt();
                        x = scan.next().charAt(0) - 64;

                        Rule play1 = new Rule(map, x, y, 1);
                        if(play1.checkMove()){
                            map[x][y]=1;
                            map= play1.Move();
                            board.print();
                            break;
                        }
                        else
                            System.out.println("You cant choose this place");
                    }
                    if (!chechPass1){
                        System.out.println("PASS");
                        break;
                    }
                }
                if(!board.checkOver()){
                    while (true){
                        System.out.println("Black: ");
                        boolean chechPass2 = false;
                        for (int counter1=1; counter1<=8; counter1++) {
                            for (int counter2 = 1; counter2 <= 8; counter2++) {
                                Rule play = new Rule(map, counter2, counter1, 2);;
                                if(play.checkMove()) {
                                    chechPass2 = true;
                                }
                            }
                        }
                        if(chechPass2){
                            y = scan.nextInt();
                            x = scan.next().charAt(0) - 64;

                            Rule play1 = new Rule(map, x, y, 2);
                            if(play1.checkMove()){
                                map[x][y]=2;
                                map= play1.Move();
                                board.print();
                                break;
                            }
                            else
                                System.out.println("You cant choose this place");
                        }
                        if (!chechPass2){
                            System.out.println("PASS");
                            break;
                        }
                    }

                }
            }
        }
    }
}
