public class Rule {
    /**
     *  we use this class that we can play by rules in 2 single
     *  or multiplayer
     *  <h2>Library  simulation  class</h2>
     *  @author Sara Tajernia
     *  @version 1.00
     *  @since 1399-1-17
     */

    private int map[][];
    private int x;
    private int y;
    private int color = 0;
    private int maxPoint=0;

    public Rule(int Map[][], int X, int Y, int Color) {
        map = Map;
        x = X;
        y = Y;
        color = Color;
    }

    public void setMap(int[][] map) {
        this.map = map;
    }

    public int[][] getMap() {
        return map;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getX() {
        return x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getY() {
        return y;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getColor() {
        return color;
    }

    public void setMaxPoint(int maxPoint) {
        this.maxPoint = maxPoint;
    }

    public int getMaxPoint() {
        return maxPoint;
    }


    /**
     * this method return us to check all the place that there
     * is any possible move for player or we have to pass
     * and also give the best place if its multiplayer
     * @return
     */
    public boolean checkMove() {
        int countPoint;
        boolean check = false;
        if (map[x][y] == 0) {                       //check if there is no nuts that dont have the same color or empty
            if ((map[x + 1][y] == 0 || map[x + 1][y] == color) &&       //place all over the chosen nut
                    (map[x - 1][y] == 0 || map[x - 1][y] == color) &&
                    (map[x][y + 1] == 0 || map[x][y + 1] == color) &&
                    (map[x][y - 1] == 0 || map[x][y - 1] == color) &&
                    (map[x + 1][y + 1] == 0 || map[x + 1][y + 1] == color) &&
                    (map[x - 1][y + 1] == 0 || map[x - 1][y + 1] == color) &&
                    (map[x + 1][y - 1] == 0 || map[x + 1][y - 1] == color) &&
                    (map[x - 1][y - 1] == 0 || map[x - 1][y - 1] == color)
            ) {
                return false;
            }
            else{
                if(map[x+1][y] != color && map[x+1][y] != 0){
                    for (int counter=x+1; counter<9; counter++){     //check player get some point in right
                        if (map[counter][y] == 0) {
                            break;
                        }
                        if(map[counter][y] == color){
                            maxPoint+= counter-x-1;
                            check = true;
                            break;
                        }
                    }
                }
                if(map[x-1][y] != color && map[x-1][y] != 0){
                    for (int counter=x-1; 0<counter; counter--){     //check player get some point in left
                        if (map[counter][y] == 0) {
                            break;
                        }
                        if(map[counter][y] == color){
                            maxPoint+= x-counter-1;
                            check = true;
                            break;
                        }
                    }
                }
                if(map[x][y+1] != color && map[x][y+1] != 0){
                    for (int counter=y+1; counter<9; counter++){     //check player get some point in down
                        if (map[x][counter] == 0) {
                            break;
                        }
                        if(map[x][counter] == color){
                            maxPoint+= counter-y-1;
                            check = true;
                            break;
                        }
                    }
                }
                if(map[x][y-1] != color && map[x][y-1] != 0){
                    for (int counter=y-1; 0<counter; counter--){     //check player get some point in up
                        if (map[x][counter] == 0) {
                            break;
                        }
                        if(map[x][counter] == color){
                            maxPoint+= y-counter-1;
                            check = true;
                            break;
                        }
                    }
                }
                if(map[x+1][y+1] != color && map[x+1][y+1] != 0){
                    int Counter = x+1;
                    for (int counter=y+1; counter<9 && Counter<9; counter++){     //check player get some point in down-right
                        if (map[Counter][counter] == 0) {
                            break;
                        }
                        if(map[Counter][counter] == color){
                            maxPoint+= counter-y-1;
                            check = true;
                            break;
                        }
                        Counter++;
                    }
                }
                if(map[x-1][y+1] != color && map[x-1][y+1] != 0){
                    int Counter = x-1;
                    for (int counter=y+1; counter<9 && 0<Counter; counter++){     //check player get some point in down-left
                        if (map[Counter][counter] == 0) {
                            break;
                        }
                        if(map[Counter][counter] == color){
                            maxPoint+= counter-y-1;
                            check = true;
                            break;
                        }
                        Counter--;
                    }
                }
                if(map[x+1][y-1] != color && map[x+1][y-1] != 0){
                    int Counter = x+1;
                    for (int counter=y-1; 0<counter && Counter<9; counter--){     //check player get some point in up-right
                        if (map[Counter][counter] == 0) {
                            break;
                        }
                        if(map[Counter][counter] == color){
                            maxPoint+= y-counter-1;
                            check = true;
                            break;
                        }
                        Counter++;
                    }
                }
                if(map[x-1][y-1] != color && map[x-1][y-1] != 0){
                    int Counter = x-1;
                    for (int counter=y-1; 0<counter && 0<Counter; counter--){     //check player get some point in up-left
                        if (map[Counter][counter] == 0) {
                            break;
                        }
                        if(map[Counter][counter] == color){
                            maxPoint+= y-counter-1;
                            check = true;
                            break;
                        }
                        Counter--;
                    }
                }
            }
            if(check){
                    return true;
            }
            else
                return false;                                                   //cant get any point
        }
        else {
            return false;                                                       //This place is taken
        }
    }


    /**
     * we use this method to put a new nut in board and
     * alse move other nuts around it if they have to
     * @return
     */
    public int[][] Move(){

        if(map[x+1][y] != color && map[x+1][y] != 0){
            boolean check1 = false;
            for (int counter=x+1; counter<9; counter++){     //check player get some point
                if (map[counter][y] == 0) {
                    check1=false;
                    break;
                }
                if(map[counter][y] == color){
                    check1=true;
                    break;
                }
            }
            if (check1) {
                for (int Counter = x + 1; Counter < 9; Counter++) {
                    if (map[Counter][y] != color && map[Counter][y] != 0) {
                        map[Counter][y] = color;                             //move the nut from right
                    }
                    else
                        break;
                }
            }
        }
        if(map[x-1][y] != color && map[x-1][y] != 0){
            boolean check2 = false;
            for (int counter=x-1; 0<counter; counter--){     //check player get some point
                if (map[counter][y] == 0) {
                    check2=false;
                    break;
                }
                if(map[counter][y] == color){
                    check2=true;
                    break;
                }
            }
            if (check2) {
                for (int Counter = x - 1; 0<Counter; Counter--) {
                    if (map[Counter][y] != color && map[Counter][y] != 0) {
                        map[Counter][y] = color;                            //move the nut from left
                    }
                    else
                        break;
                }
            }
        }
        if(map[x][y+1] != color && map[x][y+1] != 0){
            boolean check3 = false;
            for (int counter=y+1; counter<9; counter++){     //check player get some point
                if (map[x][counter] == 0) {
                    check3=false;
                    break;
                }
                if(map[x][counter] == color){
                    check3=true;
                    break;
                }
            }
            if (check3) {
                for (int Counter = y+1; Counter<9; Counter++) {
                    if (map[x][Counter] != color && map[x][Counter] != 0) {
                        map[x][Counter] = color;                            //move the nut from down
                    }
                    else
                        break;
                }
            }
        }
        if(map[x][y-1] != color && map[x][y-1] != 0){
            boolean check4 = false;
            for (int counter=y-1; 0<counter; counter--){     //check player get some point
                if (map[x][counter] == 0) {
                    check4=false;
                    break;
                }
                if(map[x][counter] == color){
                    check4=true;
                    break;
                }
            }
            if (check4) {
                for (int Counter = y-1; 0<Counter; Counter--) {
                    if (map[x][Counter] != color && map[x][Counter] != 0) {
                        map[x][Counter] = color;                            //move the nut from uo
                    }
                    else
                        break;
                }
            }
        }
        if(map[x+1][y+1] != color && map[x+1][y+1] != 0){
            boolean check5 = false;
            int counter2 = x+1;
            for (int counter=y+1; counter<9 && counter2<9; counter++){     //check player get some point
                if (map[counter2][counter] == 0) {
                    check5=false;
                    break;
                }
                if(map[counter2][counter] == color){
                    check5=true;
                    break;
                }
                counter2++;
            }
            if (check5) {
                int Counter2 = x+1;
                for (int Counter = y+1; Counter<9 && Counter2<9; Counter++) {
                    if (map[Counter2][Counter] != color && map[Counter2][Counter] != 0) {
                        map[Counter2][Counter] = color;                            //move the nut from down-right
                    }
                    else
                        break;
                    Counter2++;
                }
            }
        }
        if(map[x-1][y+1] != color && map[x-1][y+1] != 0){
            boolean check6 = false;
            int counter2 = x-1;
            for (int counter=y+1; counter<9 && 0<counter2; counter++){     //check player get some point
                if (map[counter2][counter] == 0) {
                    check6=false;
                    break;
                }
                if(map[counter2][counter] == color){
                    check6=true;
                    break;
                }
                counter2--;
            }
            if (check6) {
                int Counter2 = x-1;
                for (int Counter = y+1; Counter<9 && 0<Counter2; Counter++) {
                    if (map[Counter2][Counter] != color && map[Counter2][Counter] != 0) {
                        map[Counter2][Counter] = color;                            //move the nut from down-left
                    }
                    else
                        break;
                    Counter2--;
                }
            }
        }
        if(map[x+1][y-1] != color && map[x+1][y-1] != 0){
            boolean check7= false;
            int counter2 = x+1;
            for (int counter=y-1; 0<counter && counter2<9; counter--){     //check player get some point
                if (map[counter2][counter] == 0) {
                    check7=false;
                    break;
                }
                if(map[counter2][counter] == color){
                    check7=true;
                    break;
                }
                counter2++;
            }
            if (check7) {
                int Counter2 = x+1;
                for (int Counter = y-1; 0<Counter2 && Counter2<9; Counter--) {
                    if (map[Counter2][Counter] != color && map[Counter2][Counter] != 0) {
                        map[Counter2][Counter] = color;                            //move the nut from up-right
                    }
                    else
                        break;
                    Counter2++;
                }
            }
        }
        if(map[x-1][y-1] != color && map[x-1][y-1] != 0){
            boolean check8 = false;
            int counter2 = x-1;
            for (int counter=y-1; 0<counter && 0<counter2; counter--){     //check player get some point;
                if (map[counter2][counter] == 0) {
                    check8=false;
                    break;
                }
                if(map[counter2][counter] == color){
                    check8=true;
                    break;
                }
                counter2--;
            }
            if (check8) {
                int Counter2 = x-1;
                for (int Counter = y-1; 0<Counter && 0<Counter2; Counter--) {
                    if (map[Counter2][Counter] != color && map[Counter2][Counter] != 0) {
                        map[Counter2][Counter] = color;                            //move the nut from up-left
                    }
                    else
                        break;
                    Counter2--;
                }
            }
        }
        return map;
    }
}
