public class Board {

    /**
     *  we use this class to check if the game is over
     *  and print the board
     *  <h2>Library  simulation  class</h2>
     *  @author Sara Tajernia
     *  @version 1.00
     *  @since 1399-1-17
     */

    private int map[][];

    public Board(int Map[][]){
        map = Map;
    }

    public void setMap(int[][] map) {
        this.map = map;
    }

    public int[][] getMap() {
        return map;
    }

    public boolean checkOver(){                                 //check is the game is over
        int w =0;
        int b =0;
        for (int counter1=0; counter1<9; counter1++){
            for (int counter2=0; counter2<9; counter2++){
                if(map[counter1][counter2] == 1)
                    w++;
                if(map[counter1][counter2] == 2)
                    b++;
            }
        }
        if(w + b >= 64 || w == 0 || b == 0){            //if the board is full or or one of the nuts is 0
            System.out.println("Game Over");
            if(w>b)
                System.out.println("White Win");
            else if(w<b)
                System.out.println("Black win");
            else
                System.out.println("Even");
            return true;
        }
        else
            return false;
    }

    public void print(){                            //print the board

        System.out.println("    A    B    C    D    E    F    G    H");
        System.out.print("   ");
        for (int i = 0; i < 8; i++)
            System.out.print("____ ");
        System.out.println();

        int counterNum = 1;
        for (int y = 1; y <= 16; y++) {
            if (y % 2 == 1)
                System.out.print(counterNum++ + " ");
            if (y % 2 == 0)
                System.out.print("  ");
            for (int x = 1; x <= 8; x++){
                if(Math.abs(y/2) != (double)y/2) {
                    if (map[x][y/2+1] == 1) {                       //put the white nut
                        System.out.print("| \u26AA️ ");
                        continue;
                    }
                    if (map[x][y/2+1] == 2) {
                        System.out.print("| \u26AB️ ");              //put the black nut
                        continue;
                    }
                }
                if (y % 2 == 1)
                    System.out.print("|    ");
                if (y % 2 == 0)
                    System.out.print("|____");
            }
            System.out.println("|");
        }
        System.out.println();
    }
}
