import java.util.Random;

/**
 * we use this class only if its single player to
 * chose the best place for nut of best rotate
 */

public class Single {

    private int map[][];

    public Single(int Map[][]) {
        map = Map;
    }

    public void setMap(int[][] map) {
        this.map = map;
    }

    public int[][] getMap() {
        return map;
    }


    /**
     * we use this method to chose the best place like how
     * to win or how to stop winning the other player
     * or predict the other move of ours or other player
     */

    public void bestPlace(){                                 //chose the best place for single player
        int count1,  count2, count3, Count3, count4, Count4;
        int counter1, counter2, counter3, Counter3, counter4, Counter4;

        for (int y = 0; y < 6; y++) {                      //check if it can win the game chose the right place
            for (int x = 0; x < 6; x++) {
                if (map[x][y] == 2) {

                    for (counter1 = x; counter1 < 6; counter1++) {
                        if (map[x][y] != map[counter1][y] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter1 - x >= 4) {
                        if (x + 4 < 6 && map[x + 4][y] == 0) {
                            map[x + 4][y] = map[x][y];
                            return;
                        } else if (x - 1 >= 0 && map[x - 1][y] == 0) {
                            map[x - 1][y] = map[x][y];
                            return;
                        }
                    }
                    for (counter2 = y; counter2 < 6; counter2++) {
                        if (map[x][y] != map[x][counter2] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter2 - y >= 4) {
                        if (y + 4 < 6 && map[x][y + 4] == 0) {
                            map[x][y + 4] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && map[x][y - 1] == 0) {
                            map[x][y - 1] = map[x][y];
                            return;
                        }
                    }
                    for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
                        if (map[x][y] != map[counter3][Counter3] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter3 - x >= 4) {
                        if (y + 4 < 6 && x + 4 < 6 && map[x + 4][y + 4] == 0) {
                            map[x + 4][y + 4] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && x - 1 >= 0 && map[x - 1][y - 1] == 0) {
                            map[x - 1][y - 1] = map[x][y];
                            return;
                        }
                    }
                    for (counter4 = x, Counter4 = y; 0 <= counter4 && Counter4 < 6; counter4--, Counter4++) {
                        if (map[x][y] != map[counter4][Counter4] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (Counter4 - y >= 4) {
                        if (y + 4 < 6 && 0 <= x - 4 && map[x - 4][y + 4] == 0) {
                            map[x - 4][y + 4] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && x + 1 < 6 && map[x + 1][y - 1] == 0) {
                            map[x + 1][y - 1] = map[x][y];
                            return;
                        }
                    }
                }
            }
        }

        for (int y = 0; y < 6; y++) {                   //check if the competitor can win the game in next play stop it
            for (int x = 0; x < 6; x++) {
                if (map[x][y] == 1) {
                    for (count1 = x; count1 < 6; count1++) {
                        if (map[x][y] != map[count1][y] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (count1 - x >= 4) {
                        if (x + 4 < 6 && map[x + 4][y] == 0) {
                            map[x + 4][y] = 2;
                            return;
                        } else if (x - 1 >= 0 && map[x - 1][y] == 0) {
                            map[x - 1][y] = 2;
                            return;
                        }
                    }
                    for (count2 = y; count2 < 6; count2++) {
                        if (map[x][y] != map[x][count2] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (count2 - y >= 4) {
                        if (y + 4 < 6 && map[x][y + 4] == 0) {
                            map[x][y + 4] = 2;
                            return;
                        } else if (y - 1 >= 0 && map[x][y - 1] == 0) {
                            map[x][y - 1] = 2;
                            return;
                        }
                    }
                    for (count3 = x, Count3 = y; count3 < 6 && Count3 < 6; count3++, Count3++) {
                        if (map[x][y] != map[count3][Count3] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (count3 - x >= 4) {
                        if (y + 4 < 6 && x + 4 < 6 && map[x + 4][y + 4] == 0) {
                            map[x + 4][y + 4] = 2;
                            return;
                        } else if (y - 1 >= 0 && x - 1 >= 0 && map[x - 1][y - 1] == 0) {
                            map[x - 1][y - 1] = 2;
                            return;
                        }
                    }
                    for (count4 = x, Count4 = y; 0 <= count4 && Count4 < 6; count4--, Count4++) {
                        if (map[x][y] != map[count4][Count4] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (Count4 - y >= 4) {
                        if (y + 4 < 6 && 0 <= x - 4 && map[x - 4][y + 4] == 0) {
                            map[x - 4][y + 4] = 2;
                            return;
                        } else if (y - 1 >= 0 && x + 1 < 6 && map[x + 1][y - 1] == 0) {
                            map[x + 1][y - 1] = 2;
                            return;
                        }
                    }
                }
            }
        }


        for (int y = 0; y < 6; y++) {                       //check if we have 3 nut in the line chose a place that
            for (int x = 0; x < 6; x++) {                      //we can make it 4
                if (map[x][y] == 2) {
                    for (counter1 = x; counter1 < 6; counter1++) {
                        if (map[x][y] != map[counter1][y] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter1 - x >= 3) {
                        if (x + 3 < 6 && map[x + 3][y] == 0) {
                            map[x + 3][y] = map[x][y];
                            return;
                        } else if (x - 1 >= 0 && map[x - 1][y] == 0) {
                            map[x - 1][y] = map[x][y];
                            return;
                        }
                    }
                    for (counter2 = y; counter2 < 6; counter2++) {
                        if (map[x][y] != map[x][counter2] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter2 - y >= 3) {
                        if (y + 3 < 6 && map[x][y + 3] == 0) {
                            map[x][y + 3] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && map[x][y - 1] == 0) {
                            map[x][y - 1] = map[x][y];
                            return;
                        }
                    }
                    for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
                        if (map[x][y] != map[counter3][Counter3] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter3 - x >= 3) {
                        if (y + 3 < 6 && x + 3 < 6 && map[x + 3][y + 3] == 0) {
                            map[x + 3][y + 3] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && x - 1 >= 0 && map[x - 1][y - 1] == 0) {
                            map[x - 1][y - 1] = map[x][y];
                            return;
                        }
                    }
                    for (counter4 = x, Counter4 = y; 0 <= counter4 && Counter4 < 6; counter4--, Counter4++) {
                        if (map[x][y] != map[counter4][Counter4] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (Counter4 - y >= 3) {
                        if (y + 3 < 6 && 0 <= x - 3 && map[x - 4][y + 3] == 0) {
                            map[x - 3][y + 3] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && x + 1 < 6 && map[x + 1][y - 1] == 0) {
                            map[x + 1][y - 1] = map[x][y];
                            return;
                        }
                    }
                }
            }
        }

        for (int y = 0; y < 6; y++) {                   //if 3 nuts of the other player is making a line and both
            for (int x = 0; x < 6; x++) {                   //end of line is empty and we cant win in next 2 roll chose
                if (map[x][y] == 1) {                           //one of the place to stop winning the competitor
                    for (count1 = x; count1 < 6; count1++) {
                        if (map[x][y] != map[count1][y] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (count1 - x >= 3) {
                        if (x + 3 < 6 && map[x + 3][y] == 0) {
                            map[x + 3][y] = 2;
                            return;
                        } else if (x - 1 >= 0 && map[x - 1][y] == 0) {
                            map[x - 1][y] = 2;
                            return;
                        }
                    }
                    for (count2 = y; count2 < 6; count2++) {
                        if (map[x][y] != map[x][count2] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (count2 - y >= 3) {
                        if (y + 3 < 6 && map[x][y + 3] == 0) {
                            map[x][y + 3] = 2;
                            return;
                        } else if (y - 1 >= 0 && map[x][y - 1] == 0) {
                            map[x][y - 1] = 2;
                            return;
                        }
                    }
                    for (count3 = x, Count3 = y; count3 < 6 && Count3 < 6; count3++, Count3++) {
                        if (map[x][y] != map[count3][Count3] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (count3 - x >= 3) {
                        if (y + 3 < 6 && x + 3 < 6 && map[x + 3][y + 3] == 0) {
                            map[x + 3][y + 3] = 2;
                            return;
                        } else if (y - 1 >= 0 && x - 1 >= 0 && map[x - 1][y - 1] == 0) {
                            map[x - 1][y - 1] = 2;
                            return;
                        }
                    }
                    for (count4 = x, Count4 = y; 0 <= count4 && Count4 < 6; count4--, Count4++) {
                        if (map[x][y] != map[count4][Count4] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (Count4 - y >= 4) {
                        if (y + 3 < 6 && 0 <= x - 3 && map[x - 3][y + 3] == 0) {
                            map[x - 3][y + 3] = 2;
                            return;
                        } else if (y - 1 >= 0 && x + 1 < 6 && map[x + 1][y - 1] == 0) {
                            map[x + 1][y - 1] = 2;
                            return;
                        }
                    }
                }
            }
        }


        for (int y = 0; y < 6; y++) {                       //if there is 2 nuts making a line chose a place to
            for (int x = 0; x < 6; x++) {                       //make it 3
                if(map[x][y] == 2){

                   for (counter1 = x; counter1 < 6; counter1++) {
                       if (map[x][y] != map[counter1][y] || map[x][y] == 0) {
                           break;
                       }
                   }
                   if(counter1 - x >= 2){
                       if(x+2<6 && map[x+2][y]==0) {
                           map[x + 2][y] = map[x][y];
                           return;
                       }
                       else if(x-1>=0 && map[x-1][y]==0) {
                           map[x - 1][y] = map[x][y];
                           return;
                       }
                   }
                   for (counter2 = y; counter2 < 6; counter2++) {
                       if (map[x][y] != map[x][counter2] || map[x][y] == 0) {
                           break;
                       }
                   }
                   if(counter2 - y >= 2){
                       if(y+2<6 && map[x][y+2]==0) {
                           map[x][y+2] = map[x][y];
                           return;
                       }
                       else if(y-1>=0 && map[x][y-1]==0) {
                           map[x][y-1] = map[x][y];
                           return;
                       }
                   }
                   for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
                       if (map[x][y] != map[counter3][Counter3] || map[x][y] == 0) {
                           break;
                       }
                   }
                   if(counter3 - x >= 2){
                       if(y+2<6 && x+2<6 && map[x+2][y+2]==0){
                           map[x+2][y+2] = map[x][y];
                           return;
                       }
                       else if(y-1>=0 && x-1>=0 && map[x-1][y-1]==0){
                           map[x-1][y - 1] = map[x][y];
                           return;
                       }
                   }
                   for (counter4 = x, Counter4 = y; 0<=counter4 && Counter4 < 6; counter4--, Counter4++) {
                       if (map[x][y] != map[counter4][Counter4] || map[x][y] == 0) {
                           break;
                       }
                   }
                   if(Counter4 - y >= 2){
                       if(y+2<6 && 0<=x-2 && map[x-2][y+2]==0){
                           map[x-2][y+2] = map[x][y];
                           return;
                       }
                       else if(y-1>=0 && x+1<6 && map[x+1][y-1]==0){
                           map[x+1][y - 1] = map[x][y];
                           return;
                       }
                   }
               }
            }
        }

        for (int y = 0; y < 6; y++) {                           //if there is 1 nut chose a place to make it 2
            for (int x = 0; x < 6; x++) {
                if (map[x][y] == 2) {
                    for (counter1 = x; counter1 < 6; counter1++) {
                        if (map[x][y] != map[counter1][y] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter1 - x >= 1) {
                        if (x + 1 < 6 && map[x + 1][y] == 0) {
                            map[x + 1][y] = map[x][y];
                            return;
                        } else if (x - 1 >= 0 && map[x - 1][y] == 0) {
                            map[x - 1][y] = map[x][y];
                            return;
                        }
                    }
                    for (counter2 = y; counter2 < 6; counter2++) {
                        if (map[x][y] != map[x][counter2] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter2 - y >= 1) {
                        if (y + 1 < 6 && map[x][y + 1] == 0) {
                            map[x][y + 1] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && map[x][y - 1] == 0) {
                            map[x][y - 1] = map[x][y];
                            return;
                        }
                    }
                    for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
                        if (map[x][y] != map[counter3][Counter3] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (counter3 - x >= 1) {
                        if (y + 1 < 6 && x + 1 < 6 && map[x + 1][y + 1] == 0) {
                            map[x + 1][y + 1] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && x - 1 >= 0 && map[x - 1][y - 1] == 0) {
                            map[x - 1][y - 1] = map[x][y];
                            return;
                        }
                    }
                    for (counter4 = x, Counter4 = y; 0 <= counter4 && Counter4 < 6; counter4--, Counter4++) {
                        if (map[x][y] != map[counter4][Counter4] || map[x][y] == 0) {
                            break;
                        }
                    }
                    if (Counter4 - y >= 1) {
                        if (y + 1 < 6 && 0 <= x - 1 && map[x - 1][y + 1] == 0) {
                            map[x - 1][y + 1] = map[x][y];
                            return;
                        } else if (y - 1 >= 0 && x + 1 < 6 && map[x + 1][y - 1] == 0) {
                            map[x + 1][y - 1] = map[x][y];
                            return;
                        }
                    }
                    System.out.println(counter1 + counter2 + counter3 + counter4);

                }
            }
        }

        Random rand = new Random();
        while (true) {                                      //if there is not a nut in board make a random place
            int randX = rand.nextInt(6);
            System.out.println(randX);
            int randY = rand.nextInt(6);
            System.out.println(randY);
            if (map[randX][randY] == 0) {
                map[randX][randY] = 2;
                return;
            }
        }
    }


    /**
     * we use this method to chose the best rotate like how
     * to win or how to stop winning the other player
     * or predict the other move of ours or other player
     */

    public void bestRotate(){                                    //chose the best rotate for single player

        Turn turnObj = new Turn(map);

        int test[][] = new int [6][6];
        for (int block=1; block<5; block++) {                   //check if we can win by rotate right
            for (int turn = 1; turn < 3; turn++) {

                for (int counter1 = 0; counter1 < 6; counter1++) {
                    for (int counter2 = 0; counter2 < 6; counter2++) {
                        test[counter2][counter1] = map[counter2][counter1];
                    }
                }

                turnObj.rotate(block, turn, test);
                Board boardObj = new Board(test);
                if(boardObj.gameOver() && boardObj.getWinner()[0]==2){
                    turnObj.rotate(block,turn,map);
                    return;
                }
            }
        }

        for (int block=1; block<5; block++) {               //if the other player cant win by rotate, rotete the other way
            for (int turn = 1; turn < 3; turn++) {              //that can not win by just one rotate

                for (int counter1 = 0; counter1 < 6; counter1++) {
                    for (int counter2 = 0; counter2 < 6; counter2++) {
                        test[counter2][counter1] = map[counter2][counter1];
                    }
                }

                turnObj.rotate(block, turn, test);
                Board boardObj = new Board(test);
                if(boardObj.gameOver() && boardObj.getWinner()[0]==1){
                    if(turn==1){
                       turnObj.rotate(block, 2,map);
                       return;
                    }
                    if(turn==2){
                        turnObj.rotate(block, 1,map);
                        return;
                    }
                }
            }
        }

        for (int block=1; block<5; block++) {               //chose if we can make a 4 nuts line by rotating
            for (int turn = 1; turn < 3; turn++) {
                for (int Counter1 = 0; Counter1 < 6; Counter1++) {
                    for (int Counter2 = 0; Counter2 < 6; Counter2++) {
                        test[Counter2][Counter1] = map[Counter2][Counter1];
                    }
                }
                int counter1, counter2, counter3, Counter3, counter4, Counter4;
                turnObj.rotate(block, turn, test);


                for (int y=0; y<6; y++) {
                    for (int x = 0; x < 6; x++) {

                        for (counter1 = x; counter1 < 6; counter1++) {
                            if (test[x][y] != test[counter1][y] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(counter1 - x >= 4){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                        for (counter2 = y; counter2 < 6; counter2++) {
                            if (test[x][y] != test[x][counter2] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(counter2 - y >= 4){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                        for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
                            if (test[x][y] != test[counter3][Counter3] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(counter3 - x >= 4){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                        for (counter4 = x, Counter4 = y; 0 <= counter4 && Counter4 < 6; counter4--, Counter4++) {
                            if (test[x][y] != test[counter4][Counter4] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(Counter4 - y >= 4){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                    }
                }
            }
        }


        for (int block=1; block<5; block++) {               //chose if we can make a 3 nuts line by rotating
            for (int turn = 1; turn < 3; turn++) {
                for (int Counter1 = 0; Counter1 < 6; Counter1++) {
                    for (int Counter2 = 0; Counter2 < 6; Counter2++) {
                        test[Counter2][Counter1] = map[Counter2][Counter1];
                    }
                }
                int counter1, counter2, counter3, Counter3, counter4, Counter4;
                turnObj.rotate(block, turn, test);
                Board boardObj = new Board(test);


                for (int y=0; y<6; y++) {
                    for (int x = 0; x < 6; x++) {

                        for (counter1 = x; counter1 < 6; counter1++) {
                            if (test[x][y] != test[counter1][y] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(counter1 - x >= 3){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                        for (counter2 = y; counter2 < 6; counter2++) {
                            if (test[x][y] != test[x][counter2] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(counter2 - y >= 3){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                        for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
                            if (test[x][y] != test[counter3][Counter3] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(counter3 - x >= 3){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                        for (counter4 = x, Counter4 = y; 0 <= counter4 && Counter4 < 6; counter4--, Counter4++) {
                            if (test[x][y] != test[counter4][Counter4] || test[x][y] == 0) {
                                break;
                            }
                        }
                        if(Counter4 - y >= 3){
                            turnObj.rotate(block,turn,map);
                            return;
                        }
                    }
                }
            }
        }

         Random rand = new Random();                    //make a random block and turn right or left for rotating
         int randBlock = rand.nextInt(4)+1;
         int randTurn = rand.nextInt(2)+1;
         Turn turn = new Turn(map);
         turn.rotate(randBlock, randTurn, map);

    }

}
