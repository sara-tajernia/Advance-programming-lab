import java.util.Scanner;
/**
 *  Pentago game
 *  we use this class to test all the classes that we made
 *  and give input by scanning we have 2 kind of multiplayer
 *  and single player and scan the place by only 2 number(x,y)
 *  and rotate by scanning the number of block and turn to
 *  right or left
 *  <h2>Library  simulation  class</h2>
 *  @author Sara Tajernia
 *  @version 1.00
 *  @since 1399-1-23
 */
public class Main {

    public static void main(String[] args)
    throws InterruptedException{

        int map[][] = new int[6][6];

        for (int counter1 = 0; counter1 < 6; counter1++) {                  //all the element in map are 0
            for (int counter2 = 0; counter2 < 6; counter2++) {
                map[counter1][counter2] = 0;
            }
        }

        Board board = new Board(map);
        board.print();
        Scanner scan = new Scanner(System.in);
        Turn turn = new Turn(map);

        System.out.println("1) single player");                           //menu
        System.out.println("2) multi player");

        int Menu = scan.nextInt();


        if (Menu==1){                                                    //single player
            Single single = new Single(map);
            while (true) {                                               //scan 2 num (x,y) until a proper input
                int x, y, block, Turn, menu;                                //scan jast only 2 number
                if (!board.gameOver()) {                                 //check the game is not over
                    while (true) {
                        System.out.println("White: ");                   //white turn choose a place
                        x = scan.nextInt();
                        y = scan.nextInt();
                        if (map[x][y] != 0) {                            //check the place is not full
                            System.out.println("This place is full");
                            continue;
                        } else
                            map[x][y] = 1;
                        board.print();
                        break;
                    }
                } else
                    break;
                if (!board.gameOver()) {
                    if (turn.checkBlock()) {                          //if we have a empty block or the block dont change
                        System.out.println("1)move      2)pass");       //if we rotate it we can pass rotating
                        menu = scan.nextInt();
                        if (menu == 1) {                              //if we want to rotate chose the block and how we
                            System.out.println("Block: ");              //we want to rotate it
                            block = scan.nextInt();
                            System.out.println("1) turn right      2)turn left");
                            Turn = scan.nextInt();
                            turn.rotate(block, Turn, map);
                            board.print();
                        }
                        else if (menu == 2) {
                            board.print();
                        }
                    }
                    else {
                        System.out.println("Block: ");
                        block = scan.nextInt();
                        System.out.println("1) turn right      2)turn left");
                        Turn = scan.nextInt();
                        turn.rotate(block, Turn, map);
                        board.print();
                    }
//                    Thread.sleep(3000);
                } else
                    break;
                if (!board.gameOver()) {
                    single.bestPlace();                               //chose the best place for nut
                    board.print();
                    Thread.sleep(3000);
                }
                else
                    break;
                if (!board.gameOver()) {
                    single.bestRotate();                              //chose the best rotate
                    board.print();
                }
                else
                    break;
            }
        }
        

        if (Menu == 2) {                                               //multi player game
            while (true) {                                                 //its just like the first player in single player
                int x, y, block, Turn, menu;
                if (!board.gameOver()) {

                    while (true) {
                        System.out.println("White: ");
                        x = scan.nextInt();
                        y = scan.nextInt();
                        if (map[x][y] != 0) {
                            System.out.println("This place is full");
                            continue;
                        } else
                            map[x][y] = 1;
                        board.print();
                        break;
                    }
                } else
                    break;
                if (!board.gameOver()) {
                    if (turn.checkBlock()) {
                        System.out.println("1)move      2)pass");
                        menu = scan.nextInt();
                        if (menu == 1) {
                            System.out.println("Block: ");
                            block = scan.nextInt();
                            System.out.println("1) turn right      2)turn left");
                            Turn = scan.nextInt();
                            turn.rotate(block, Turn, map);
                            board.print();
                        } else if (menu == 2) {
                            board.print();
                        }
                    } else {
                        System.out.println("Block: ");
                        block = scan.nextInt();
                        System.out.println("1) turn right      2)turn left");
                        Turn = scan.nextInt();
                        turn.rotate(block, Turn, map);
                        board.print();
                    }
                } else
                    break;
                if (!board.gameOver()) {
                    while (true) {                                                   //white turn choose a place
                        System.out.println("Red: ");
                        x = scan.nextInt();
                        y = scan.nextInt();
                        if (map[x][y] != 0) {
                            System.out.println("This place is full");
                            continue;
                        } else
                            map[x][y] = 2;
                        board.print();
                        break;
                    }
                } else
                    break;
                if (!board.gameOver()) {
                    if (turn.checkBlock()) {
                        System.out.println("1)move      2)pass");
                        menu = scan.nextInt();
                        if (menu == 1) {
                            System.out.println("Block: ");
                            block = scan.nextInt();
                            System.out.println("1) turn right      2)turn left");
                            Turn = scan.nextInt();
                            turn.rotate(block, Turn, map);
                            board.print();
                        } else if (menu == 2) {
                            board.print();
                        }
                    } else {
                        System.out.println("Block: ");
                        block = scan.nextInt();
                        System.out.println("1) turn right      2)turn left");
                        Turn = scan.nextInt();
                        turn.rotate(block, Turn, map);
                        board.print();
                    }
                } else
                    break;
            }
        }
    }

}
