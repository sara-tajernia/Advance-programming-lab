import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

/**
 *  UNO Game
 *  This class can play uno in single player and multi player by use all
 *  the classes and check all the rules like mission cards and limit the
 *  players to play by rules
 *  <h2>Library  simulation  class</h2>
 *  @author Sara Tajernia
 *  @version 1.00
 *  @since 1398-12-26
 */

public class Main {

    public static void main(String[] args)
            throws InterruptedException{
        ArrayList<Card> card = new ArrayList<>();                                 //Arraylist that sava bank cards

        Card test1 = new Card(0, 'b');                                 //add 108 cards to Arraylist Card
        card.add(test1);
        Card test2 = new Card(0, 'y');
        card.add(test2);
        Card test3 = new Card(0, 'r');
        card.add(test3);
        Card test4 = new Card(0, 'g');
        card.add(test4);

        for (int counter1=1; counter1<13; counter1++){
            for (int count=0; count<2; count++) {
                Card Test1 = new Card(counter1, 'b');
                card.add(Test1);
                Card Test2 = new Card(counter1, 'y');
                card.add(Test2);
                Card Test3 = new Card(counter1, 'r');
                card.add(Test3);
                Card Test4 = new Card(counter1, 'g');
                card.add(Test4);
            }
        }
        for (int count=0; count<4; count++) {
            Card Test1 = new Card(13, 'w');
            card.add(Test1);
            Card Test2 = new Card(14, 'w');
            card.add(Test2);
        }
        Scanner scan = new Scanner(System.in);

        System.out.println("1) single player");                                 //menu
        System.out.println("2) multiplayer");

        int number= scan.nextInt();


        if (number==1) {                                                       //single player
            System.out.println("Select the number of payers!");
            System.out.println("1)Three players\n2)Four players\n3)Five players");

            Random rand = new Random();
            int menu = scan.nextInt();
            ArrayList<Card> player[] = new ArrayList[menu + 2];

            for (int i = 0; i < menu + 2; i++) {
                player[i] = new ArrayList<Card>();
            }

            for (int i = 0; i < menu + 2; i++) {                        //chose 7 random card for each players and
                for (int counter2 = 0; counter2 < 7; counter2++) {          // add them to their Arraylist and remove
                    Card test = card.get(rand.nextInt(card.size()));            //remove those from Card
                    player[i].add(test);
                    card.remove(test);
                }
            }
            Rules rules = new Rules(player);
            Card saveCard;                                  //save the middle card because of the next card
            char saveColor;                                 //save the  middle card because of the next card and change different card
            int saveBank = 0;                               //save number of +2 cards
            int saveBank2 = 0;                              //save number of +4 cards
            int direction = 0;                              //save clockwise or anticlockwise
            boolean done0 = true, done1 = true, done2 = true, done4 = true;  //save if mission card has done the job or not

            int first;
            while (true) {                              //chose the random card for first card and
                first = rand.nextInt(card.size());          //also check they are not change color cards
                if (card.get(first).getNum() != 13 && card.get(first).getNum() != 14) {
                    saveCard = card.get(first);
                    saveColor = saveCard.getColor();
                    saveCard.printCard();
                    break;
                }
            }

            int turn = rand.nextInt(menu + 2);      //chose the random number for first turn
            if (saveCard.getNum() == 11) {                 //do the job if the first cord is mission card
                direction = 1;
                done1 = false;
            }
            if (saveCard.getNum() == 12) {
                done2 = false;
                int counter = 0;
                Iterator<Card> it = player[turn].iterator();
                while (it.hasNext()) {
                    Card check = it.next();
                    if (check.getNum() == 12) {
                        saveBank += 2;
                        counter++;
                        break;
                    }
                }
                if (counter==0){
                    SpecialCard specialCard3 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                    turn = specialCard3.plus2();
                    done2 = true;
                    saveBank = 0;
                }
            }

            while (true) {
                while (turn < menu + 2 && 0 <= turn) {
                    if (!rules.gameOver()) {
                        for (int i = 0; i < player.length; i++)
                            System.out.println("player" + (i + 1) + ": " + player[i].size());
                        Thread.sleep(2000);             //sleep to show the other cards better
                        if (direction == 0)
                            System.out.println("\nclockwise");
                        else
                            System.out.println("\nanticlockwise");
                        System.out.println("player" + (turn + 1) + ":");
                        if (turn == 0) {                    //its my turn
                            while (true) {
                                rules.myCard(turn);             //if i dont have any card to chose add bank option
                                SpecialCard specialCard0 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                if (!specialCard0.check(turn)) {
                                    System.out.println((player[turn].size() + 1) + ") Bank");
                                }
                                int a = scan.nextInt();         //chose one of the options
                                int counter = 0;
                                if (a <= player[turn].size()) {
                                    Card Test = player[turn].get(a - 1);
                                    if (saveBank != 0 && Test.getNum() != 12) {       //check savaBank is empty or other wise I have to chose +2 card
                                        System.out.println("You have to chose +2 card!");
                                        continue;
                                    }
                                    if (saveBank2 != 0 && Test.getNum() != 14) {     //check savaBank2 is empty or other wise I have to chose +4 card
                                        System.out.println("You have to chose +4 card!");
                                        continue;
                                    }
                                    if (Test.getColor() == saveColor || Test.getNum() == saveCard.getNum() || Test.getColor() == 'w') {
                                        Iterator<Card> it = player[turn].iterator();            //chose a cord that have the same number or same color
                                        while (it.hasNext()) {                                      //of saveCard
                                            Card check = it.next();
                                            if (check.getNum() == saveCard.getNum() || check.getColor() == saveColor) {
                                                if (Test.getColor() == 'w' && Test.getNum() == 14 && saveCard.getNum() != 14) {
                                                    System.out.println("You cant chose this card!");  //you cant chose +4 card if you have another option
                                                    counter++;
                                                    break;
                                                }
                                            }
                                        }
                                        if (counter != 0 && saveBank2 == 0) {
                                            continue;
                                        }
                                        if (Test.getNum() == 10)     //if it was mission card save that the job is not done yet
                                            done0 = false;
                                        if (Test.getNum() == 11)
                                            done1 = false;
                                        if (Test.getNum() == 12)
                                            done2 = false;
                                        if (Test.getNum() == 14)
                                            done4 = false;

                                        card.add(saveCard);        //change the middle card and add the last one to the Card
                                        saveCard = Test;
                                        saveColor = Test.getColor();
                                        player[turn].remove(Test);
                                        saveCard.printCard();
                                        break;

                                    }
                                } else if (a == player[turn].size() + 1) {   //if chose the bank option
                                    done0 = true;          //change the done to dont do the mission another time
                                    done1 = true;               //to the next player
                                    done2 = true;
                                    done4 = true;
                                    Card test = card.get(rand.nextInt(card.size()));
                                    player[turn].add(test);
                                    card.remove(test);
                                    SpecialCard specialCards1 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                    if (!specialCards1.check(turn)) {
                                        break;
                                    }

                                }
                            }
                        } else {                    //the other players turn
                            while (true) {
                                Iterator<Card> it = player[turn].iterator();
                                int counter = 0;
                                if (saveBank != 0) {            //chose the +2 card if I have to
                                    while (it.hasNext()) {
                                        Card plus2 = it.next();
                                        if (plus2.getNum() == 12) {
                                            card.add(saveCard);
                                            saveCard = plus2;
                                            saveColor = plus2.getColor();
                                            player[turn].remove(plus2);
                                            saveCard.printCard();
                                            counter++;
                                            break;
                                        }
                                    }
                                    break;
                                }
                                if (saveBank2 != 0) {        //chose the +4 card if I have to
                                    while (it.hasNext()) {
                                        Card plus4 = it.next();
                                        if (plus4.getNum() == 14) {
                                            card.add(saveCard);
                                            saveCard = plus4;
                                            saveColor = plus4.getColor();
                                            player[turn].remove(plus4);
                                            saveCard.printCard();
                                            counter++;
                                            break;
                                        }
                                    }
                                    break;
                                }
                                while (it.hasNext()) {
                                    Card test = it.next();           //chose a cord that have the same number or same color of saveCard
                                    if (test.getColor() == saveColor || test.getNum() == saveCard.getNum() && test.getNum() != 14) {
                                        if (test.getNum() == 10)
                                            done0 = false;
                                        if (test.getNum() == 11)
                                            done1 = false;
                                        if (test.getNum() == 12)
                                            done2 = false;
                                        if (test.getNum() == 14)
                                            done4 = false;
                                        card.add(saveCard);
                                        saveCard = test;
                                        saveColor = test.getColor();
                                        player[turn].remove(test);
                                        saveCard.printCard();
                                        counter++;
                                        break;
                                    }
                                }

                                Iterator<Card> It1 = player[turn].iterator();
                                while (It1.hasNext() && counter == 0) { //chose the change color card
                                    Card test = It1.next();
                                    if (test.getColor() == 'w' && test.getNum() == 13) {
                                        card.add(saveCard);
                                        saveCard = test;
                                        saveColor = test.getColor();
                                        player[turn].remove(test);
                                        saveCard.printCard();
                                        counter++;
                                        break;
                                    }
                                }

                                Iterator<Card> It = player[turn].iterator();
                                while (It.hasNext() && counter == 0) {  //chose the wild draw card
                                    Card test = It.next();
                                    if (test.getColor() == 'w' && test.getNum() == 14) {
                                        done4 = false;
                                        card.add(saveCard);
                                        saveCard = test;
                                        saveColor = test.getColor();
                                        player[turn].remove(test);
                                        saveCard.printCard();
                                        counter++;
                                        break;
                                    }
                                }
                                if (counter == 0) {
                                    Card bank = card.get(rand.nextInt(card.size()));
                                    player[turn].add(bank);
                                    done0 = true;
                                    done1 = true;
                                    done2 = true;
                                    done4 = true;
                                    SpecialCard specialCards2 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                    System.out.println("Toke a card from bank");
                                    if (!specialCards2.check(turn)) {
                                        break;
                                    }
                                } else
                                    break;
                            }
                        }
                        if (saveCard.getNum() == 10 && !done0) {          //do the mission if its skip card
                            SpecialCard specialCard1 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            turn = specialCard1.skip();
                            done0 = true;
                        }
                        if (saveCard.getNum() == 11 && !done1) {          //do the mission if its reverse card
                            SpecialCard specialCard2 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            direction = specialCard2.reverse();
                            done1 = true;
                        }

                        if (saveCard.getNum() == 12 && !done2) {          //do the mission if its draw card
                            int counter = 0;
                            if (direction == 0 && turn == menu + 1) {
                                Iterator<Card> it = player[0].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 0 && turn != menu + 1) {
                                Iterator<Card> it = player[turn + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1 && turn == 0) {
                                Iterator<Card> it = player[menu + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1) {
                                Iterator<Card> it = player[turn - 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            }
                            if (counter == 0) {
                                SpecialCard specialCard3 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                turn = specialCard3.plus2();
                                done2 = true;
                                saveBank = 0;
                            }
                        }
                        if (saveCard.getNum() == 13 && saveColor=='w') {              //do the mission if its change color card
                            SpecialCard specialCard4 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            saveColor = specialCard4.change();
                        }

                        if (saveCard.getNum() == 14 && !done4) {     //do the mission if its wild draw card
                            int counter = 0;
                            if (direction == 0 && turn == menu + 1) {
                                Iterator<Card> it = player[0].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 0 && turn != menu + 1) {
                                Iterator<Card> it = player[turn + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1 && turn == 0) {
                                Iterator<Card> it = player[menu + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1) {
                                Iterator<Card> it = player[turn - 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            }
                            if (counter == 0) {
                                SpecialCard specialCard3 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                saveColor = specialCard3.plus4();
                                turn = specialCard3.skip();
                                done4 = true;
                                saveBank2 = 0;
                            }
                        }
                        if (rules.gameOver()){
                            rules.winner();
                            break;
                        }
                    }
                    if (direction == 0)             //change the turn
                        turn++;
                    if (direction == 1)
                        turn--;
                }
                if (direction == 0)                 //if turn is 0 or the same as players number handle it
                    turn = 0;
                if (direction == 1)
                    turn = menu + 1;
                if (rules.gameOver())
                    break;
            }
        }



        if (number==2) {            //multi player game with n number player just like single player my turn

            Random rand = new Random();
            int chose;
            while (true) {
                System.out.println("Enter the number of payers!");
                chose = scan.nextInt();
                if (chose>15){              //number of players cant be more that 15 becouse if it is we cant give each 7 cards
                    System.out.println("You have more than 15 players!!");
                }
                break;
            }
            int menu = chose-2;
            ArrayList<Card> player[] = new ArrayList[menu + 2];

            for (int i = 0; i < menu + 2; i++) {
                player[i] = new ArrayList<Card>();
            }

            for (int i = 0; i < menu + 2; i++) {
                for (int counter2 = 0; counter2 < 7; counter2++) {
                    Card test = card.get(rand.nextInt(card.size()));
                    player[i].add(test);
                    card.remove(test);
                }
            }
            Rules rules = new Rules(player);
            Card saveCard;
            char saveColor;
            int saveBank = 0;
            int saveBank2 = 0;
            int direction = 0;
            boolean done0 = true, done1 = true, done2 = true, done4 = true;

            int first;
            while (true) {
                first = rand.nextInt(card.size());
                if (card.get(first).getNum() != 13 && card.get(first).getNum() != 14) {
                    saveCard = card.get(first);
                    saveColor = saveCard.getColor();
                    saveCard.printCard();
                    break;
                }
            }

            int turn = rand.nextInt(menu + 2);
            if (saveCard.getNum() == 11) {                 //do the job if the first cord is mission card
                direction = 1;
                done1 = false;
            }
            if (saveCard.getNum() == 12) {
                done2 = false;
                int counter = 0;
                Iterator<Card> it = player[turn].iterator();
                while (it.hasNext()) {
                    Card check = it.next();
                    if (check.getNum() == 12) {
                        saveBank += 2;
                        counter++;
                        break;
                    }
                }
                if (counter==0){
                    SpecialCard specialCard3 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                    turn = specialCard3.plus2();
                    done2 = true;
                    saveBank = 0;
                }
            }

            while (true) {
                while (turn < menu + 2 && 0 <= turn) {
                    if (true) {
                        for (int i = 0; i < player.length; i++)
                            System.out.println("player" + (i + 1) + ": " + player[i].size());
                        if (direction == 0)
                            System.out.println("\nclockwise");
                        else
                            System.out.println("\nanticlockwise");
                        System.out.println("player" + (turn + 1) + ":");
                        while (true) {
                            rules.myCard(turn);
                            SpecialCard specialCard0 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            if (!specialCard0.check(turn)) {
                                System.out.println((player[turn].size() + 1) + ") Bank");
                            }
                            int a = scan.nextInt();
                            int counter = 0;
                            if (a <= player[turn].size()) {
                                Card Test = player[turn].get(a - 1);
                                if (saveBank != 0 && Test.getNum() != 12) {
                                    System.out.println("You have to chose +2 card!");
                                    continue;
                                }
                                if (saveBank2 != 0 && Test.getNum() != 14) {
                                    System.out.println("You have to chose +4 card!");
                                    continue;
                                }
                                if (Test.getColor() == saveColor || Test.getNum() == saveCard.getNum() || Test.getColor() == 'w') {
                                    Iterator<Card> it = player[turn].iterator();
                                    while (it.hasNext()) {
                                        Card check = it.next();
                                        if (check.getNum() == saveCard.getNum() || check.getColor() == saveColor) {
                                            if (Test.getColor() == 'w' && Test.getNum() == 14 && saveCard.getNum() != 14) {
                                                System.out.println("You cant chose this card!");
                                                counter++;
                                                break;
                                            }
                                        }
                                    }
                                    if (counter != 0 && saveBank2 == 0) {
                                        continue;
                                    }
                                    if (Test.getNum() == 10)
                                        done0 = false;
                                    if (Test.getNum() == 11)
                                        done1 = false;
                                    if (Test.getNum() == 12)
                                        done2 = false;
                                    if (Test.getNum() == 14)
                                        done4 = false;

                                    card.add(saveCard);
                                    saveCard = Test;
                                    saveColor = Test.getColor();
                                    player[turn].remove(Test);
                                    saveCard.printCard();
                                    break;

                                }
                            } else if (a == player[turn].size() + 1) {
                                done0 = true;
                                done1 = true;
                                done2 = true;
                                done4 = true;
                                Card test = card.get(rand.nextInt(card.size()));
                                player[turn].add(test);
                                card.remove(test);
                                SpecialCard specialCards1 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                if (!specialCards1.check(turn)) {
                                    break;
                                }
                            }
                        }
                        if (saveCard.getNum() == 10 && !done0) {
                            SpecialCard specialCard1 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            turn = specialCard1.skip();
                            done0 = true;
                        }
                        if (saveCard.getNum() == 11 && !done1) {
                            SpecialCard specialCard2 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            direction = specialCard2.reverse();
                            done1 = true;
                        }
                        if (saveCard.getNum() == 12 && !done2) {          //do the mission if its draw card
                            int counter = 0;
                            if (direction == 0 && turn == menu + 1) {
                                Iterator<Card> it = player[0].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 0 && turn != menu + 1) {
                                Iterator<Card> it = player[turn + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1 && turn == 0) {
                                Iterator<Card> it = player[menu + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1) {
                                Iterator<Card> it = player[turn - 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 12) {
                                        saveBank += 2;
                                        counter++;
                                        break;
                                    }
                                }
                            }
                            if (counter == 0) {
                                SpecialCard specialCard3 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                turn = specialCard3.plus2();
                                done2 = true;
                                saveBank = 0;
                            }
                        }
                        if (saveCard.getNum() == 13 && saveColor=='w') {
                            SpecialCard specialCard4 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                            saveColor = specialCard4.change();
                        }

                        if (saveCard.getNum() == 14 && !done4) {
                            int counter = 0;
                            if (direction == 0 && turn == menu + 1) {
                                Iterator<Card> it = player[0].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 0 && turn != menu + 1) {
                                Iterator<Card> it = player[turn + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1 && turn == 0) {
                                Iterator<Card> it = player[menu + 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            } else if (direction == 1) {
                                Iterator<Card> it = player[turn - 1].iterator();
                                while (it.hasNext()) {
                                    Card check = it.next();
                                    if (check.getNum() == 14) {
                                        saveBank2 += 4;
                                        counter++;
                                        break;
                                    }
                                }
                            }
                            if (counter == 0) {
                                SpecialCard specialCard3 = new SpecialCard(card, player, saveCard, saveColor, direction, turn, number, menu, saveBank, saveBank2);
                                saveColor = specialCard3.plus4();
                                turn = specialCard3.skip();
                                done4 = true;
                                saveBank2 = 0;
                            }
                        }
                    }
                    if (rules.gameOver()){
                        rules.winner();
                        break;
                    }
                    if (direction == 0)
                        turn++;
                    if (direction == 1)
                        turn--;
                }
                if (direction == 0)
                    turn = 0;
                if (direction == 1)
                    turn = menu + 1;
                if (rules.gameOver())
                    break;
            }
        }

    }
}

