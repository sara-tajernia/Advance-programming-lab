import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.IntStream;

/**
 * we use this card to check if the game is over or not
 * and if it is count each point and print it from less
 * to the highest one
 * and can print the players card
 */
public class Rules {

    ArrayList<Card> players[];

    public Rules(ArrayList<Card>[] players){
        this.players = players;
    }

    public void setPlayers(ArrayList<Card>[] players) { this.players = players; }

    public ArrayList<Card>[] getPlayers() { return players; }

    /**
     * This method can remove specific element from array
     * @param a
     * @param index
     * @return
     */
    public static int[] remove(int[] a, int index) {
        if (a == null || index < 0 || index >= a.length) {
            return a;
        }

        return IntStream.range(0, a.length)
                .filter(i -> i != index)
                .map(i -> a[i])
                .toArray();
    }

    /**
     * This method can count each point and print it from less
     * to the highest one
     */
    public void winner(){
        int score[] = new int[players.length];
        for (int j=0; j<players.length; j++) {
            Iterator<Card> it = players[j].iterator();
            while (it.hasNext()) {
                Card count = it.next();
                if (count.getNum() < 10) {
                    score[j] += count.getNum();
                }
                if (count.getNum() < 13 && 9 < count.getNum()) {
                    score[j] += 20;
                }
                if (count.getNum() < 15 && 12 < count.getNum()) {
                    score[j] += 50;
                }
            }
        }
        int k=0;
        int rate=1;
        System.out.println("GAME OVER");
        int score2[] = score;
        while (k< score.length) {
            int min= score[0];
            int index = 0;
            for (int ktr = 0; ktr < score.length; ktr++) {
                if (score[ktr] < min) {
                    min = score[ktr];
                    index = ktr;
                }
            }
            int index2 = 0;
            for (int l=0; l<score2.length; l++){
                if (score2[l] == min){
                    index2=l;
                }
            }
            System.out.println(rate++ +") player" + (index2+1) + ": " + min);
            score = remove(score, index);
        }

    }

    public boolean gameOver(){
        for (int i=0; i<players.length; i++){
            if(players[i].size() == 0)
                return true;
        }
        return false;
    }

    /**
     * This method can print all the players card
     * @param playerNum
     */
    public void myCard(int playerNum){
        int counter=1;
        Iterator<Card> it = players[playerNum].iterator();
        System.out.println("Select my cards: ");
        while (it.hasNext()){
            Card test = it.next();
            System.out.print(counter++ +") ");
            if(test.getColor() == 'b' && test.getNum()<10){
                System.out.println("\033[0;34m" +test.getNum() +" Blue\033[0;30m");
            }
            if(test.getColor() == 'y' && test.getNum()<10){
                System.out.println("\033[0;33m" +test.getNum() +" Yellow\033[0;30m");
            }
            if(test.getColor() == 'r' && test.getNum()<10){
                System.out.println("\033[0;31m" +test.getNum() +" Red\033[0;30m");
            }
            if(test.getColor() == 'g' && test.getNum()<10){
                System.out.println("\033[0;32m" +test.getNum() +" Green\033[0;30m");
            }
            if(test.getNum()>9 && test.getNum()<13){
                if(test.getColor()=='b'){
                    if (test.getNum()==10)
                        System.out.println("\033[0;34mSkip" +" Blue\033[0;30m");
                    if (test.getNum()==11)
                        System.out.println("\033[0;34mReverse" +" Blue\033[0;30m");
                    if (test.getNum()==12)
                        System.out.println("\033[0;34m+2"  +" Blue\033[0;30m");
                }
                if(test.getColor()=='y'){
                    if (test.getNum()==10)
                        System.out.println("\033[0;33mSkip" +" Yellow\033[0;30m");
                    if (test.getNum()==11)
                        System.out.println("\033[0;33mReverse" +" Yellow\033[0;30m");
                    if (test.getNum()==12)
                        System.out.println("\033[0;33m+2"  +" Yellow\033[0;30m");
                }
                if(test.getColor()=='r'){
                    if (test.getNum()==10)
                        System.out.println("\033[0;31mSkip" +" Red\033[0;30m");
                    if (test.getNum()==11)
                        System.out.println("\033[0;31mReverse" +" Red\033[0;30m");
                    if (test.getNum()==12)
                        System.out.println("\033[0;31m+2"  +" Red\033[0;30m");
                }
                if(test.getColor()=='g'){
                    if (test.getNum()==10)
                        System.out.println("\033[0;32mSkip" +" Green\033[0;30m");
                    if (test.getNum()==11)
                        System.out.println("\033[0;32mReverse" +" Green\033[0;30m");
                    if (test.getNum()==12)
                        System.out.println("\033[0;32m+2"  +" Green\033[0;30m");
                }
            }
            if(test.getNum() == 13){
                System.out.println("\033[0;30mChange\uD83C\uDFA8");
            }
            if(test.getNum() == 14){
                System.out.println("\033[0;30m+4\uD83E\uDD1A\uD83C\uDFFC");
            }
        }
    }
}
