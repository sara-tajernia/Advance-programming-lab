public class Card {
    /**
     * we use this class to print the cards by getting
     * their color and number
     */

    private int num;
    private char color;
    private String hue;
    private String hueNum;

    public Card(int num, char color){
        this.num = num;
        this.color = color;
        setHue(color);
        setHueNum(color);
    }

    public void setNum(int num) { this.num = num; }

    public int getNum() { return num; }

    public void setColor(char color) { this.color = color; }

    public char getColor() { return color; }

    public void setHue(char color) {
        if(color == 'b')
            hue = "\033[0;104m";
        if(color == 'y')
            hue = "\033[0;103m";
        if(color == 'r')
            hue = "\033[0;101m";
        if(color == 'g')
            hue = "\033[0;102m";
        if(color == 'w')
            hue = "\033[0;100m";
    }
    public String getHue() {
        return hue;
    }
    public void setHueNum(char color){
        if(color == 'b')
            hueNum = "\033[4;34m";
        if(color == 'y')
            hueNum = "\033[4;33m";
        if(color == 'r')
            hueNum = "\033[4;31m";
        if(color == 'g')
            hueNum = "\033[4;32m";
        if(color == 'w')
            hueNum = "\033[4;30m";
    }

    public String getHueNum() {
        return hueNum;
    }

    public void printCard(){

        System.out.println(hue + "              \033[0;30m");
        System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");

        if(num>=0 && num<10) {
            System.out.println(hue + "  \033[0;30m    " + hueNum + "   \033[0;30m   " + hue + "  \033[0;30m");
            System.out.println(hue + "  \033[0;30m    " + hueNum + " \033[0;30m" + hueNum + num + " \033[0;30m   " + hue + "  \033[0;30m");
        }
        if (num==10){
            System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
            System.out.println(hue + "  \033[0;30m   " + hueNum +"Skip\033[0;30m" +"️\uD83D\uDEAB " + hue + "  \033[0;30m");
        }
        if (num==11){
            System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
            System.out.println(hue + "  \033[0;30m " + hueNum +"Reverse\033[0;30m" +"️\uD83D\uDD04" + hue + "  \033[0;30m");
        }
        if (num==12){
            System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
            System.out.println(hue + "  \033[0;30m    " + hueNum +"+2\033[0;30m" +"✌️" +"  " + hue + "  \033[0;30m");
        }
        if (num==13){
            System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
            System.out.println(hue + "  \033[0;30m " + hueNum +"Change\033[0;30m" +"️\uD83C\uDFA8 " + hue + "  \033[0;30m");
        }
        if (num==14){
            System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
            System.out.println(hue + "  \033[0;30m    " + hueNum +"+4\033[0;37m" +"️\uD83E\uDD1A\uD83C\uDFFC  " + hue + "  \033[0;30m");
        }
        System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
        System.out.println(hue + "  \033[0;30m          " + hue + "  \033[0;30m");
        System.out.println(hue + "              \033[0;30m");
    }
}
