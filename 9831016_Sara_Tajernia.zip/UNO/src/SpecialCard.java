import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class SpecialCard {
    /**
     * we use this class for mission cards(skip, reverse, draw, change color, wild draw)
     * and return something that they change like turn or color or element of Arraylist
     */
    ArrayList<Card> card;
    ArrayList<Card> player[];
    private Card saveCard;
    private char saveColor;
    private int direction;
    private int turn;
    private int number;
    private int menu;
    private int saveBank;
    private int saveBank2;

    public SpecialCard(ArrayList<Card> card, ArrayList<Card>[] players, Card saveCard,
                       char saveColor, int direction, int turn, int number, int menu, int saveBank, int saveBank2){
        this.card = card;
        this.player = players;
        this.saveCard = saveCard;
        this.saveColor = saveColor;
        this.direction = direction;
        this.turn = turn;
        this.number = number;
        this.menu = menu;
        this.saveBank = saveBank;
        this.saveBank2 = saveBank2;
    }


    public void setCard(ArrayList<Card> card) { this.card = card; }

    public ArrayList<Card> getCard() { return card; }

    public void setPlayers(ArrayList<Card>[] players) { this.player = players; }

    public ArrayList<Card>[] getPlayers() { return player; }

    public void setSaveCard(Card saveCard) { this.saveCard = saveCard; }

    public Card getSaveCard() { return saveCard; }

    public void setSaveColor(char saveColor) { this.saveColor = saveColor; }

    public char getSaveColor() { return saveColor; }

    public void setDirection(int direction) { this.direction = direction; }

    public int getDirection() { return direction; }

    public void setTurn(int turn) { this.turn = turn; }

    public int getTurn() { return turn; }

    public void setChose(int chose) { this.number = number; }

    public int getChose() { return number; }

    public void setMnue(int mnue) { this.menu = mnue; }

    public int getMnue() { return menu; }

    public void setSaveBank(int saveBank){ this.saveBank = saveBank; }

    public int getSaveBank() { return saveBank; }

    public void setSaveBank2(int saveBank2) { this.saveBank2 = saveBank2; }

    public int getSaveBank2() { return saveBank2; }

    /**
     * This method can skip turn and check if turn is 0 or
     * the same as players number handle it
     * @return
     */
    public int skip(){
        if(direction== 0) {
            if (turn ==menu+1)
                turn = 0;
            else
                turn++;
        }
        else  {
            if (turn == 0)
                turn = menu+1;
            else
                turn--;
        }
        return turn;
    }

    public int reverse(){

        if(direction== 0)
            return 1;
        else
            return 0;
    }

    /**
     * This method can add random saveBank cards to the specific Arraylist
     * @return
     */
    public int plus2(){
        Random rand = new Random();
        if(direction== 0) {
            if (turn == menu + 1) {
                for (int i=0; i<saveBank+2; i++){
                    Card bank = card.get(rand.nextInt(card.size()));
                    player[0].add(bank);
                    card.remove(bank);
                }
                return skip();
            }
            for (int i=0; i<saveBank+2; i++){
                Card bank = card.get(rand.nextInt(card.size()));
                player[turn+1].add(bank);
                card.remove(bank);
            }
            return skip();
        }
        else {
            if (turn == 0) {
                for (int i=0; i<saveBank+2; i++){
                    Card bank = card.get(rand.nextInt(card.size()));
                    player[menu+1].add(bank);
                    card.remove(bank);
                }
                return skip();
            }
            for (int i=0; i<saveBank+2; i++){
                Card bank = card.get(rand.nextInt(card.size()));
                player[turn-1].add(bank);
                card.remove(bank);
            }
            return skip();
        }
    }

    /**
     * This method can change the saveColor
     * @return
     */

    public char change(){
        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        int chose;
        System.out.println("Choose the color\n \033[0;34m1)Blue   \033[0;33m2)Yellow   \033[0;31m3)Red   \033[0;32m4)Green  \033[0;30m");
        if (number == 1){
            if (turn == 0) {
                chose = scan.nextInt();
            }
            else {
                chose = rand.nextInt(4) + 1;
            }
        }
        else
            chose = scan.nextInt();

        if(chose==1) {
            System.out.println("\033[0;34m1)Blue \033[0;30m");
            saveColor = 'b';
        }
        if(chose==2) {
            System.out.println("\033[0;33m2)Yellow \033[0;30m");
            saveColor = 'y';
        }
        if(chose==3) {
            System.out.println("\033[0;31m3)Red \033[0;30m");
            saveColor = 'r';
        }
        if(chose==4) {
            System.out.println("\033[0;32m4)Green \033[0;30m");
            saveColor = 'g';
        }

        return saveColor;
    }

    /**
     * Tis method can change the saveColor and add random
     * saveBank2 cards to the specific Arraylist
     * @return
     */
    public char plus4(){
        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        int chose;
        System.out.println("Choose the color\n \033[0;34m1)Blue   \033[0;33m2)Yellow   \033[0;31m3)Red   \033[0;32m4)Green  \033[0;30m");
        if (number == 1){
            if (turn == 0) {
                chose = scan.nextInt();
            } else {
                chose = rand.nextInt(4) + 1;
            }
        }
        else
            chose = scan.nextInt();
        if(chose==1) {
            System.out.println("\033[0;34m1)Blue \033[0;30m");
            saveColor = 'b';
        }
        if(chose==2) {
            System.out.println("\033[0;33m2)Yellow \033[0;30m");
            saveColor = 'y';
        }
        if(chose==3) {
            System.out.println("\033[0;31m3)Red \033[0;30m");
            saveColor = 'r';
        }
        if(chose==4) {
            System.out.println("\033[0;32m4)Green \033[0;30m");
            saveColor = 'g';
        }

        if(direction== 0) {
            if (turn == menu + 1) {
                for (int i=0; i<saveBank2+4; i++){
                    Card bank = card.get(rand.nextInt(card.size()));
                    player[0].add(bank);
                    card.remove(bank);
                }
                return saveColor;
            }
            for (int i=0; i<saveBank2+4; i++){
                Card bank = card.get(rand.nextInt(card.size()));
                player[turn+1].add(bank);
                card.remove(bank);
            }
            return saveColor;
        }
        else {
            if (turn == 0) {
                for (int i=0; i<saveBank2+4; i++){
                    Card bank = card.get(rand.nextInt(card.size()));
                    player[menu+1].add(bank);
                    card.remove(bank);
                }
                return saveColor;
            }
            for (int i=0; i<saveBank2+4; i++){
                Card bank = card.get(rand.nextInt(card.size()));
                player[turn-1].add(bank);
                card.remove(bank);
            }
            return saveColor;
        }
    }

    /**
     * This method check if player can chose any card
     * or need to add a cord from bank
     * @param playerNum
     * @return
     */

    public boolean check(int playerNum){
        Iterator<Card> it = player[playerNum].iterator();
        while (it.hasNext()){
            Card check = it.next();
            if (check.getColor() == saveColor || check.getNum() == saveCard.getNum() || check.getColor() == 'w') {
                return true;
            }
        }
        return false;
    }

}
