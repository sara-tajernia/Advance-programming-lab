public class Turn{
    /**
     * we use this class to rotate the specific block
     * and check if wa have the choice to retate or not
     */

    private int map[][];

    public Turn(int Map[][]) {
        map = Map;
    }

    public void setMap(int[][] map) {
        this.map = map;
    }

    public int[][] getMap() {
        return map;
    }

    /**
     * we use this method to check if we have a empty block or
     * the block dont change if we rotate it we can pass
     * rotating return true that we can choose to dont rotate
     * @return
     */

    public boolean checkBlock(){                                //if we have a empty block or the block dont change
        int check[]= new int[8];                                    //if we rotate it we can pass rotating return true
        for (int i=0; i<8; i++)                                     //that we can choose to dont rotate
            check[i]=0;
        int counter=0;
        int test[][] = new int [6][6];
        for (int block=1; block<5; block++) {
            for (int turn = 1; turn < 3; turn++) {

                for (int counter1 = 0; counter1 < 6; counter1++) {      //save map to test to dont change map
                    for (int counter2 = 0; counter2 < 6; counter2++) {
                        test[counter2][counter1] = map[counter2][counter1];
                    }
                }

                rotate(block, turn, test);                      //if the rotate test is the same as map
                for (int counter1=0; counter1<6; counter1++){
                    for (int counter2=0; counter2<6; counter2++){
                        if(test[counter2][counter1] != map[counter2][counter1])
                            check[counter]++;
                    }
                }
                counter++;
            }
        }
        if (check[0]==0 ||check[1]==0 ||check[2]==0 ||check[3]==0 ||check[4]==0 ||check[5]==0 ||check[6]==0 ||check[7]==0)
            return true;
        else
            return false;
    }

    /**
     * we use this method to rotate a chosen block
     * to the chosen way
     * @param block
     * @param turn
     * @param map
     */


    public void rotate(int block, int turn, int map[][]){           //rotate the map by get specific block and how to rotate

        int test[][] = new int [6][6];

        for (int counter1=0; counter1<6; counter1++){
            for (int counter2=0; counter2<6; counter2++){
                test[counter1][counter2] = map[counter1][counter2];
            }
        }

        if(block==1){
            if (turn==1) {
                map[2][0] = test[0][0];
                map[2][1] = test[1][0];
                map[2][2] = test[2][0];
                map[1][0] = test[0][1];
                map[1][2] = test[2][1];
                map[0][0] = test[0][2];
                map[0][1] = test[1][2];
                map[0][2] = test[2][2];
            }
            if(turn==2) {
                map[0][2] = test[0][0];
                map[0][1] = test[1][0];
                map[0][0] = test[2][0];
                map[1][2] = test[0][1];
                map[1][0] = test[2][1];
                map[2][2] = test[0][2];
                map[2][1] = test[1][2];
                map[2][0] = test[2][2];
            }
        }
        if(block==2){
            if (turn==1) {
                map[5][0] = test[3][0];
                map[5][1] = test[4][0];
                map[5][2] = test[5][0];
                map[4][0] = test[3][1];
                map[4][2] = test[5][1];
                map[3][0] = test[3][2];
                map[3][1] = test[4][2];
                map[3][2] = test[5][2];
            }
            if(turn==2) {
                map[3][2] = test[3][0];
                map[3][1] = test[4][0];
                map[3][0] = test[5][0];
                map[4][2] = test[3][1];
                map[4][0] = test[5][1];
                map[5][2] = test[3][2];
                map[5][1] = test[4][2];
                map[5][0] = test[5][2];
            }
        }
        if(block==3) {
            if (turn == 1) {
                map[2][3] = test[0][3];
                map[2][4] = test[1][3];
                map[2][5] = test[2][3];
                map[1][3] = test[0][4];
                map[1][5] = test[2][4];
                map[0][3] = test[0][5];
                map[0][4] = test[1][5];
                map[0][5] = test[2][5];
            }
            if (turn == 2) {
                map[0][5] = test[0][3];
                map[0][4] = test[1][3];
                map[0][3] = test[2][3];
                map[1][5] = test[0][4];
                map[1][3] = test[2][4];
                map[2][5] = test[0][5];
                map[2][4] = test[1][5];
                map[2][3] = test[2][5];
            }
        }
        if(block==4) {
            if (turn == 1) {
                map[5][3] = test[3][3];
                map[5][4] = test[4][3];
                map[5][5] = test[5][3];
                map[4][3] = test[3][4];
                map[4][5] = test[5][4];
                map[3][3] = test[3][5];
                map[3][4] = test[4][5];
                map[3][5] = test[5][5];
            }
            if (turn == 2) {
                map[3][5] = test[3][3];
                map[3][4] = test[4][3];
                map[3][3] = test[5][3];
                map[4][5] = test[3][4];
                map[4][3] = test[5][4];
                map[5][5] = test[3][5];
                map[5][4] = test[4][5];
                map[5][3] = test[5][5];
            }
        }

    }

}
