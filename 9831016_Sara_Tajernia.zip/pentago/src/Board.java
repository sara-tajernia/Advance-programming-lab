public class Board {
    /**
     * we use this class to check if game is over or not
     * and print the board
     */

    private int map[][];
    private int winner[] = new int[2];                      //chose an array for winner if they both win

    public Board(int Map[][]){
        map = Map;
    }

    public void setMap(int[][] map) {
        this.map = map;
    }

    public int[][] getMap() {
        return map;
    }

    public int[] getWinner() {
        return winner;
    }

    /**
     * we use this method to check for specific x and y
     * if they can make a 5 nuts line we only check 4 direction
     * becouse in gameOver method we checkOver from top of the
     * board and we dont need to check the other 4 direction
     * @param x
     * @param y
     * @return
     */
    public boolean checkOver(int x, int y) {                    //check if there is 5 same color nuts make a line

        int counter1, counter2, counter3, Counter3, counter4, Counter4;

        for (counter1 = x; counter1 < 6; counter1++) {
            if (map[x][y] != map[counter1][y] || map[x][y] == 0) {
                break;
            }
        }
        for (counter2 = y; counter2 < 6; counter2++) {
            if (map[x][y] != map[x][counter2] || map[x][y] == 0) {
                break;
            }
        }
        for (counter3 = x, Counter3 = y; counter3 < 6 && Counter3 < 6; counter3++, Counter3++) {
            if (map[x][y] != map[counter3][Counter3] || map[x][y] == 0) {
                break;
            }
        }
        for (counter4 = x, Counter4 = y; 0<=counter4 && Counter4 < 6; counter4--, Counter4++) {
            if (map[x][y] != map[counter4][Counter4] || map[x][y] == 0) {
                break;
            }
        }
            if (counter1 - x >= 5 || counter2 - y >= 5 || counter3 - x >= 5 || Counter4 - y >= 5 ) {
                return true;
            }
            else
                return false;
    }

    /**
     * we use this method to check all the place by checkOver
     * and announce the winner
     * @return
     */
    public boolean gameOver(){                                 //check if the game is over by using checkOver method
        boolean check=false;
        int w=0, r=0;
        for (int counter=0; counter<6; counter++){
            for (int Counter=0; Counter<6; Counter++){
                if(map[Counter][counter]==1)
                    w++;
                if(map[Counter][counter]==2)
                    r++;
            }
        }

        if(w+r == 36){                                     //the game is over if the board is full
            System.out.println("Game Over");
            return true;
        }


        winner[0]=0;
        for (int counter1=0; counter1<6; counter1++){
            for (int counter2=0; counter2<6; counter2++){
                if(checkOver(counter2, counter1)){
                    if(winner[0]==0){                       //save the winner and continue if an other line is exist too
                        winner[0] = map[counter2][counter1];
                    }
                    else if(winner[1]==0)
                        winner[1] = map[counter2][counter1];
                    check = true;
                }
            }
        }
        if(check==true){                                    //print the winner
            System.out.println("Game Over");
            if(winner[0]!=0 && winner[1]!=0 && winner[0]!=winner[1])
                System.out.println("Even");
            else if(winner[0]!=0) {
                if (winner[0] == 1)
                    System.out.println("White Win");
                if (winner[0] == 2)
                    System.out.println("Red Win");
            }
        }
        return check;
    }

    /**
     * we use this method to print the board and
     * full them by right nuts
     */
    public void print(){                                    //print the board

        System.out.println(" ️️0 ️️️ 1 ️️️ 2    3 ️️️ 4 ️️️ 5 ");
        int num=0;
        for (int counter1=0; counter1<6; counter1++){
            if(counter1==3)
                System.out.println(" ------------------------");
            System.out.print(num);
            num++;
            for (int counter2=0; counter2<6; counter2++){
                if(counter2==3)
                    System.out.print("|");
                if(map[counter2][counter1] == 0)
                    System.out.print(" ✖️️ ");
                if(map[counter2][counter1] == 1)
                    System.out.print(" ⚪️️ ");
                if(map[counter2][counter1] == 2)
                    System.out.print(" \uD83D\uDD34️️ ");
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }

}
